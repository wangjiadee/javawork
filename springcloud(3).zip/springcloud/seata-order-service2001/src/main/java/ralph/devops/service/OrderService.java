package ralph.devops.service;

import ralph.devops.doamin.Order;

/**
 * @author 80288284
 */
public interface OrderService
{
    void create(Order order);
}